#!/usr/bin/env python3
"""ساخت auth_users.json (فقط هش رمزها ذخیره می‌شود، نه خود رمز).

اجرا:  python3 make_auth_users.py
فرمت هش دقیقاً همان connector.py است (pbkdf2-sha256، ۲۰۰٬۰۰۰ تکرار).
"""
import getpass, hashlib, json, os, secrets, sys

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "auth_users.json")
ROLES = {"store": "فروشگاه", "brand": "مالک برند", "system": "مالک سیستم"}

def hash_pw(pw):
    salt = secrets.token_hex(16)
    h = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 200_000).hex()
    return f"pbkdf2${salt}${h}"

def main():
    if os.path.exists(OUT):
        if input("auth_users.json موجود است. بازنویسی شود؟ (yes/no): ").strip() != "yes":
            sys.exit("لغو شد.")
    users = []
    for role, fa in ROLES.items():
        n = int(input(f"تعداد کاربر «{fa}» ({role}): ") or 0)
        for i in range(1, n + 1):
            pw = getpass.getpass(f"  رمز {fa} {i}: ").strip()
            if len(pw) < 6:
                sys.exit("رمز باید حداقل ۶ کاراکتر باشد.")
            users.append({"id": f"{role}-{i}", "role": role, "label": f"{fa} {i}",
                          "hash": hash_pw(pw), "active": True})
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump({"users": users}, f, ensure_ascii=False, indent=1)
    print(f"✓ {len(users)} کاربر در {OUT} ذخیره شد.")

if __name__ == "__main__":
    main()
